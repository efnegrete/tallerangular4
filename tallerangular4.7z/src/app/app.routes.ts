import { ModuleWithProviders } from '@angular/core';
import { Routes, Route,  RouterModule } from '@angular/router';
import { LstuserComponent } from './register/lstuser/lstuser.component';
import { UserComponent } from './register/user/user.component';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
// Services
export const AppRoute: Route[] = [
    { path: '', component: DashboardComponent },
    { path: 'usuario', component: LstuserComponent},
    { path: 'usuario/:id', component: UserComponent}
];
