export class Reference {
  name: string;
  
}