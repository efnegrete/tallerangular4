import { Reference } from './reference';
export class User {
    public id: number;
    public name: string;
    public email: string;
    public mobile: number;
    public lastName: string;
    constructor() {}
}
