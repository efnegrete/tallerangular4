import {HttpModule} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { UserComponent } from './register/user/user.component';
import { UserService } from './services/user.service';
import { LstuserComponent } from './register/lstuser/lstuser.component';
import { RouterModule } from '@angular/router';
import { AppRoute } from './app.routes';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DataTableModule } from 'angular-4-data-table/src/index';
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    LstuserComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(AppRoute),
    DataTableModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
