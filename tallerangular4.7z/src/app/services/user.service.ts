import { Injectable } from '@angular/core';
import {Http, Headers, Response} from '@angular/http';
import { User } from '../model/user';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/operator';
 
@Injectable()
export class UserService {
    url= 'http://localhost:54391';
  controller= '/api/user';
  constructor(private _http: Http) { }
  protected testheader() {
    const headers = new Headers();
    headers.append('Accept', 'application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
    headers.append('Content-Type', 'application/json, multipart/form-data');
    headers.append('Access-Control-Allow-Methods', 'POST, GET, PUT,DELETE');
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Access-Control-Allow-Headers', 'Origin,Accept, Content-Type, X-Token');

    return headers;
}
    public getListadoJson(): Observable<User[]> {
      /*return this.http.get('./assets/data/user.json')
      .map( (res: Response) => res.json());*/
      const lstUser = new Array<User>();
      for (let _i = 1; _i < 4; _i++) {
              const user = new User();
              user.name = 'nombre ' +_i;
              lstUser.push(user);
       }
    return    Observable.of(lstUser);
    }

    getList(): Observable<User[]> {
      try {
          const aurl = this.url + this.controller ;
          console.log(aurl);
          return this._http.get(aurl,  { headers: this.testheader() })
              .map((r: Response) => r.json());
      } catch (Error) {
          throw Error;
      }
  }
       getSearch(id: number): Observable<User> {
          const aurl = this.url + this.controller + '/' + id ;
            return this._http.get(aurl, { headers: this.testheader() } )
                .map((r: Response) => r.json());
        }

        save(beUser: User): Observable<Response> {
          try {
              const content = JSON.stringify(beUser);
              if (beUser.id === 0) {
                  const aurl = this.url + this.controller;
                  return this._http.post(aurl, content, { headers: this.testheader() } );
              } else {
                const aurl = this.url + this.controller + '/' + `${beUser.id}`;
                      return this._http.put(aurl, content, { headers: this.testheader() });
              }
          } catch (Error) {
              throw Error;
          }
      }
  }
