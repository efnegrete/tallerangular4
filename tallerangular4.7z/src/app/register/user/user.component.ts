import { Component, OnInit } from '@angular/core';
import { Router , ActivatedRoute} from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../model/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user = new User();
  submitted = false;
  editName: string;
  constructor(private route: ActivatedRoute,
      private router: Router,
       private userservices: UserService) { }
   
  ngOnInit() {
     this.route.params.subscribe(params => {
          const id = +params['id'];

          if ( id !== 0) {

            this.userservices.getSearch(id)
            .subscribe(res => {

            this.editName = 'Editar Usuario';
            this.user =  <User>res;

          });
           } else {
            this.editName = 'Nuevo Usuario';
            this.user = new User();
            this.user.id = 0;
             }
                });
  }
  save() {
    this.submitted = true;
      this.userservices.save(this.user)
      .subscribe(res => {
              console.log('estado servicio: ' + res.statusText);
              this.back();
      });
  }
  back() {
    this.router.navigate(['/usuario']);
  }

}
