import {ActivatedRoute, Router} from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../model/user';
import { DataTableResource } from 'angular-4-data-table';
@Component({
  selector: 'app-lstuser',
  templateUrl: './lstuser.component.html',
  styleUrls: ['./lstuser.component.css']
})
export class LstuserComponent implements OnInit {
  lstUser: Array<User>;
  constructor(private router: Router,
    private route: ActivatedRoute,
     private userservices: UserService) { }

  ngOnInit() {
    this.lstUser = new Array<User>();
    this.userservices.getList()
     .subscribe(res => {
       this.lstUser = res;
       }
    , error => console.log(error));
  }
  editUser(item: User) {
    this.router.navigate(['/usuario', item.id]);
  }
 newUser() {
  this.router.navigate(['/usuario', 0]);
 }
}
